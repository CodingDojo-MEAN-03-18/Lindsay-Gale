var my_math_module = require('./mathlib');

my_math_module.add(2, 4);
my_math_module.multiply(2, 4);
my_math_module.square(5);
my_math_module.random(2, 4);
